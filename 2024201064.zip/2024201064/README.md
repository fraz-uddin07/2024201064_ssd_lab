In Question 1 :
	Using "grep" command to search for "POST", then skipping any number of characters usign ".*" and then searching for "404" in file "access.log". This gives us all lines that have "POST" followed by "404" somewhere in each line.
	
In Question 2:
	Using awk with delimiter set to ',' adding up all the values of the fourth column in variable sum and then printing the value of sum at the end.
