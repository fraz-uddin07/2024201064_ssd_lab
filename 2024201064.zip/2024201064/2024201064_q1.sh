#!/usr/bin/bash
grep "POST.*404" access.log
